---
name: Voxel Laundromat Workspace
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0d0e10'
  surface-container-low: '#1b1b1d'
  surface-container: '#1f2021'
  surface-container-high: '#292a2b'
  surface-container-highest: '#343536'
  on-surface: '#e4e2e4'
  on-surface-variant: '#c4c6cd'
  inverse-surface: '#e4e2e4'
  inverse-on-surface: '#303032'
  outline: '#8e9197'
  outline-variant: '#44474c'
  surface-tint: '#b8c8e0'
  primary: '#c2d3eb'
  on-primary: '#223145'
  primary-container: '#a7b7cf'
  on-primary-container: '#39485c'
  inverse-primary: '#505f75'
  secondary: '#bac7dd'
  on-secondary: '#243142'
  secondary-container: '#3d4a5c'
  on-secondary-container: '#acb9cf'
  tertiary: '#edcca4'
  on-tertiary: '#402d10'
  tertiary-container: '#d0b18a'
  on-tertiary-container: '#594325'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d3e4fd'
  primary-fixed-dim: '#b8c8e0'
  on-primary-fixed: '#0c1c2f'
  on-primary-fixed-variant: '#38485c'
  secondary-fixed: '#d6e3fa'
  secondary-fixed-dim: '#bac7dd'
  on-secondary-fixed: '#0f1c2d'
  on-secondary-fixed-variant: '#3b485a'
  tertiary-fixed: '#ffddb4'
  tertiary-fixed-dim: '#e1c199'
  on-tertiary-fixed: '#291801'
  on-tertiary-fixed-variant: '#594324'
  background: '#131315'
  on-background: '#e4e2e4'
  surface-variant: '#343536'
  mc-app-bg: '#35372F'
  mc-header: '#416F2C'
  mc-sidebar: '#564330'
  mc-panel: '#E4D9BE'
  mc-input-raised: '#F2E8D3'
  mc-surface-muted: '#D2C1A3'
  mc-surface-hover: '#DAC8AC'
  mc-surface-selected: '#B5CB98'
  mc-border: '#887252'
  mc-text-primary: '#2A2117'
  mc-text-secondary: '#5B4A35'
  mc-text-header: '#F9F4E6'
  mc-text-sidebar: '#FFF3DD'
  mc-text-disabled: '#776E61'
  mc-primary: '#427A25'
  mc-primary-hover: '#30631C'
  mc-text-on-primary: '#FFFFFF'
  mc-secondary-accent: '#C48845'
  mc-focus: '#286B1C'
  mc-success: '#246E3C'
  mc-warning: '#835217'
  mc-danger: '#AA3535'
  mc-info: '#315F83'
  rc-app-bg: '#181A1C'
  rc-header: '#202326'
  rc-sidebar: '#292D30'
  rc-panel: '#35393D'
  rc-input-raised: '#42474C'
  rc-surface-muted: '#2C3034'
  rc-surface-hover: '#4D545A'
  rc-surface-selected: '#596068'
  rc-border: '#687178'
  rc-text-primary: '#F5F4F1'
  rc-text-secondary: '#C5C9CD'
  rc-text-header: '#F8F7F4'
  rc-text-sidebar: '#EFEFED'
  rc-text-disabled: '#95999F'
  rc-primary: '#D1D5D7'
  rc-primary-hover: '#ECEBE7'
  rc-text-on-primary: '#1B1D20'
  rc-secondary-accent: '#B7BEC2'
  rc-focus: '#ECEBE7'
  rc-success: '#8BD0A0'
  rc-warning: '#E5B978'
  rc-danger: '#F29BA2'
  rc-info: '#98BACB'
  lt-app-bg: '#F7F7F6'
  lt-header: '#FFFFFF'
  lt-sidebar: '#F1F1F0'
  lt-panel: '#FFFFFF'
  lt-input-raised: '#FAFAFA'
  lt-surface-muted: '#EEEEED'
  lt-surface-hover: '#E8E8E7'
  lt-surface-selected: '#DEDEDD'
  lt-border: '#CCCCCA'
  lt-text-primary: '#171717'
  lt-text-secondary: '#535353'
  lt-text-header: '#171717'
  lt-text-sidebar: '#202020'
  lt-text-disabled: '#848484'
  lt-primary: '#252525'
  lt-primary-hover: '#111111'
  lt-text-on-primary: '#FFFFFF'
  lt-secondary-accent: '#777777'
  lt-focus: '#424242'
  lt-success: '#237044'
  lt-warning: '#8A5A1B'
  lt-danger: '#AB333C'
  lt-info: '#424242'
  dk-app-bg: '#08090C'
  dk-header: '#050608'
  dk-sidebar: '#0F1115'
  dk-panel: '#13161B'
  dk-input-raised: '#1A1D24'
  dk-surface-muted: '#0E1014'
  dk-surface-hover: '#222630'
  dk-surface-selected: '#2C333D'
  dk-border: '#343A45'
  dk-text-primary: '#F2F3F5'
  dk-text-secondary: '#B7BEC9'
  dk-text-header: '#F1F3F5'
  dk-text-sidebar: '#E6E9EF'
  dk-text-disabled: '#858B96'
  dk-primary: '#A7B7CF'
  dk-primary-hover: '#C2D0E3'
  dk-text-on-primary: '#0D121A'
  dk-secondary-accent: '#8D9AAF'
  dk-focus: '#B1C3DE'
  dk-success: '#80C89F'
  dk-warning: '#E0B77C'
  dk-danger: '#F08A98'
  dk-info: '#B2C4E0'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
  display-md:
    fontFamily: Space Grotesk
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-md:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.5rem
  gutter-lg: 1rem
  margin: 0.75rem
  margin-panel: 1rem
  space-xs: 0.25rem
  space-sm: 0.375rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
  space-2xl: 1.5rem
---

## Brand & Style

The design system powers an internal local-first Java Minecraft structure editor engineered for technical builders, datapack creators, modded asset curators, and procedural architectural designers. It balances dense CAD-grade technical utility with playful voxel heritage. 

The interface embraces a structured **Modular Technical Minimalism** approach tailored to high-density desktop workspaces. It establishes functional parity across four personality-driven themes:
- **Minecraft**: Evokes tactile 8-bit voxel roots using green grass headers, earthy dirt navigations, and parchment panels with crisp stepped accents without introducing visual noise on deep data tables.
- **Raccoon**: A cozy, warm-toned dark-charcoal fur aesthetic featuring soft graphite planes, pill-rounded highlights, and striped high-contrast tactile elements.
- **Light**: A strictly monochrome, hyper-disciplined studio palette stripping away chromatic distractions to focus entirely on block palette authoring and geometric validation.
- **Dark**: A near-black, low-glare nocturnal workstation offering subtle blue-charcoal framing and precise pale blue focal highlights.

The original brand mark is strictly immutable across every theme, preserving its exact chromatic identity, proportions, and transparent background.

## Colors

The 23 semantic roles provide visual structure across each theme variant without mutating functional component hierarchy or interaction layouts.

### Semantic Role Structure
- **App Background**: Outer structural frame housing toolbars and viewport canvases.
- **Header / Status bar**: Global chrome framing top menus and bottom metadata counters. In Minecraft theme, uses lush canopy green (`#416F2C`) with parchment text (`#F9F4E6`).
- **Sidebar**: Tool tree, block palettes, and metadata inspectors. In Minecraft theme, features dirt brown (`#564330`) with cream foreground text (`#FFF3DD`).
- **Panel / Dialog**: Elevated modal sheets, tab groups, and flyouts.
- **Input / Raised**: Interactive fields, search inputs, dropdown triggers, and numeric steppers.
- **Surface Muted / Hover / Selected**: Layered state fills ensuring distinct interactive clarity.
- **Border**: Framing lines strictly separating layout panes without grid clutter.
- **Primary / Accent & Hover**: Main affirmative actions (Save, Apply, Place mode). Paired with deliberate `Text on Primary` high contrast.
- **Secondary Accent**: Decorative anchors, selection badges, and subtle metadata accents.
- **State Hues (Success / Warning / Danger / Info)**: Explicit indicators for validation, datapack missing namespaces, syntax errors, and telemetry indicators.

Theme colors are isolated to application chrome and dialogs; they must never tint the 3D WebGL viewport canvas, voxel mesh textures, or selected reality presets.

## Typography

The typography scale is optimized for dense spatial coordinates, compound NBT tags, block namespacing, and technical dialog configurations:
- **Display & Section Titles**: Geometric structural headings (`Space Grotesk`) provide clean visual anchors for modal headers and major panel sections.
- **Interface & Form Body**: Utilitarian sans-serif (`Inter`) delivers legibility in deep forms, nested tabs, and guidance descriptions.
- **Data, Coordinates & Block States**: Monospaced type (`JetBrains Mono`) powers coordinate readouts (`X 127 · Y 99 · Z 119`), JSON tokens, keyboard shortcut tags, and status bar metrics.

### Theme Font Customization
Under **Settings > Appearance > Interface**, user-selected font overrides alter the base interface font family dynamically:
- **Chakra Petch**: Technical, angular, and sci-fi aesthetic.
- **Comfortaa**: Rounded, organic, and approachable aesthetic matching the Raccoon theme.
- **Pangolin**: Playful, hand-drawn character complementing casual building workflows.

## Layout & Spacing

The workspace implements a zero-overhead **Docked Workbench Layout** structured around a centralized 3D viewport canvas bordered by functional sidebars and pinned chrome:
- **Global Header**: Fixed 44px height housing the brand logo, native application menu bar, mode selectors (`3D Edit` / `Y-Layer`), viewport controls (`Fit structure`, `Focus selection`, `Camera`), and status indicators.
- **Left Sidebar**: 280px fixed width, structured with segmented views (`Blocks`, `Decorations`, `Groups`), filter chips, namespace search, and virtualized block tile lists.
- **Central Viewport Canvas**: Fluid dimensional area supporting 3D structure rendering with overlay HUD chips (e.g., Quick Bar hints).
- **Right Sidebar**: 260px fixed width inspector containing context-sensitive tabs (`Selection`, `Block Usage`), blockstate property controls, and layer stepping tools.
- **Global Status Footer**: Fixed 24px height providing persistent breadcrumbs, coordinate telemetry, block counts, and engine states (`Assets ready`).

Section margins utilize `margin-panel` (1rem), while intra-element gaps adhere strictly to the 4px baseline rhythm (`space-xs` through `space-xl`) to maximize viewport real estate.

## Elevation & Depth

Visual hierarchy is maintained through distinct surface tonal levels rather than heavy ambient drop shadows, preventing visual competition with the 3D editing canvas:

- **Level 0 (Canvas Base)**: Deepest plane hosting the 3D scene grid.
- **Level 1 (Docked Chrome)**: Global Header, Footer, and pinned Sidebars rest directly on Level 0 with a 1px solid dividing border (`Border` token).
- **Level 2 (Panels & Modal Dialogs)**: Settings modal, Asset Manager, and JSON dialogs layer above the workspace. In the Dark and Raccoon themes, panels leverage a subtle 1px inner boundary highlight paired with a deep 16px blur backdrop scrim (`rgba(0, 0, 0, 0.6)`).
- **Level 3 (Raised Controls & Inputs)**: Text fields, dropdown triggers, and stepped coordinate counters raise one step above panels via `Input / Raised` fill and 1px borders.
- **Voxel Stepping (Minecraft Variant)**: Minecraft theme utilizes 2px hard-edge drop offsets (`box-shadow: 2px 2px 0px rgba(0,0,0,0.35)`) and notched corner borders rather than soft blur shadows.

## Shapes

The default shape language is **Soft (Level 1)**, providing precision corners suited for technical toolkits:
- Standard inputs, buttons, and segmented pill groups utilize `0.25rem` (4px) corner radii.
- Dialog containers, modal sheets, and preview cards use `0.5rem` (8px).

### Theme-Specific Shape Adjustments
- **Minecraft**: Overrides radius tokens to `0px` (Level 0 - Sharp). Buttons, preview cards, and segmented chips feature crisp 90-degree square corners with optional 2px pixelated voxel-cut notched borders.
- **Raccoon**: Escalates radius tokens to **Pill-shaped (Level 3)**. Containers use `1rem` (16px), and interactive buttons/chips utilize full pill geometry (`9999px`) to reinforce warm, soft tactile contours.
- **Light & Dark**: Standardize on **Soft (Level 1)** for clean architectural lines.

## Components

### Buttons & Interactive Triggers
- **Primary Action**: Filled with `Primary / Accent`, foreground `Text on Primary`. Used exclusively for constructive and finalizing actions (`Apply`, `Save & Close`, `Place`).
- **Secondary / Ghost Action**: Transparent fill with `Border` stroke, transitioning to `Surface Hover` on pointer hover. Used for auxiliary commands (`Fit structure`, `Focus selection`, `Cancel`).
- **Destructive Action**: Outlined or filled with `Danger / Error` token. Used for group deletion, layer clearance, or resetting caches.

### Settings Modal Architecture
The Settings window is a standardized dual-pane dialog:
- **Navigation (Left, 180px)**: 5 top-level items (`General`, `Appearance`, `Controls`, `Shortcuts`, `Accessibility`). Active state styled via `Selected Surface`.
- **Content Area (Right, Scrollable)**: Stable header and footer; internal pane scrolls vertically.
- **Appearance Tab**:
  - **Interface Subtab**: Contains 4 interactive visual theme cards (Minecraft, Raccoon, Light, Dark), font family selector (`Comfortaa`, `Chakra Petch`, `Pangolin`), and font size slider (`Small`, `Normal`, `Large`).
  - **Workspace Background Subtab**: Independent canvas environment selection (`Dark`, `Light`, `Reality`). Reality mode displays grid pickers for **Ground** (`Plains grass`, `Sand`, `Snow`, `Netherrack`, `Warped nylium`, `Crimson nylium`, `End stone`) and **Sky** (`Overworld day`, `Overworld night`, `Nether`, `The End`), featuring visual previews and active selection borders.
- **Modal Footer**: Pinned action bar containing `Reset defaults` (left-aligned), and `Cancel`, `Apply`, `Save & Close` (right-aligned).

### Form Controls & Inputs
- **Text Inputs & Dropdowns**: Built on `Input / Raised` with `Border`. Focus states render a crisp 1.5px outline with `Focus / Outline`.
- **Search Fields**: Compact 28px height, inline search icon, placeholder text in `Secondary Text`, and clear trigger (`Esc`).
- **Segmented View Switchers**: Bordered container housing sibling toggle buttons (`3D Edit` / `Y-Layer`; `Selection` / `Block Usage`), active item indicated via `Selected Surface`.

### Block Palette Tiles & Lists
- **Tile Card**: 48x48px square asset card with subtle `Border`, thumbnail center, hover tooltip showing block ID (`minecraft:dandelion`), and quick-add shortcut (`+`).