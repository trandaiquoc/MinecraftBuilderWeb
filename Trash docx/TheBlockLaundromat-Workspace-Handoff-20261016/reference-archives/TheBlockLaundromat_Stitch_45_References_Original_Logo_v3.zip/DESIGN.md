# DESIGN.md — The Block Laundromat Internal Workspace

## Objective
Redesign the **internal editor UI**, not the external homepage/project screen, for a local-first Minecraft Java structure editor. Use the 45 numbered screenshots as evidence of existing screens, controls, data and interaction states, NOT a style specification. Build one unified modern design system and express it in four equal-function variants.

## Immutable brand asset
The user already provided two official logo files:
- `assets/the-block-laundromat-logo.svg` — original SVG, primary
- `assets/the-block-laundromat-logo.png` — original transparent PNG, alternative when SVG unsupported
Never re-create, trace, stylize, regenerate, simplify, recolor, modify proportions or typography, or crop artwork. Use the supplied artwork directly in all themes, only changing its rendered size/position.

## Theme and semantic token system

# Proposed theme palette V2

**New design direction; does not modify application code, the canonical V1 palette or the outside homepage.** The 45 reference images are a temporary Dark appearance, NOT a color specification. This file is the design brief for Stitch, while `_workspace-color-palette-v1-REFERENCE.md` preserves historical semantic roles only.

## Palette design philosophy

- Keep ONE coherent semantic token system across the four application themes: Minecraft, Raccoon, Light, Dark. Different appearances should not move or rename functional controls.
- Base, surface, raised, muted, hover, selection and border must have perceptible hierarchy. Do not apply accent to every component. Primary action is more prominent than secondary actions, destructive controls retain danger semantics, disabled controls are unmistakable.
- **Minecraft**: 8-bit / chunky pixels, not flat green! The top layer evokes GREEN GRASS, the lower layer evokes BROWN DIRT, with selectively used pixel-stepped/voxel-cut transition details. Rich grass/dirt hues and stone neutral are used purposefully: do not alternate grass and dirt on every row. Crisp square controls, textured hints but no visual noise over text, especially on long technical forms.
- **Raccoon**: cozy fluffy rounded dark-gray fur, charcoal graphite, alternating pale gray and off-white patches like raccoon face/tail banding. Humorous small details but never childish or intrusive. Avoid hard mechanical/angular surfaces. Differ from Dark through warm-gray softness and light-striped highlights.
- **Light**: almost MONOCHROME, primarily white, near-black, soft gray. No blue-tinted backgrounds, icy panels or blue primary buttons. Neutral black primary actions, restrained grayscale hover/focus. Use color only when a semantic state clearly requires success/warning/danger, not as overall visual direction.
- **Dark**: genuinely dark near-black night-work interface, not saturated navy or medium-blue everywhere. Very dark background + subtle neutral blue-charcoal surfaces; limited soft pale-blue accents, accessible contrast. Low glare and legible long editing sessions.
- Status hues (success/warning/danger/info) may depart from monochrome for meaning; they should still be restrained and accessible.
- Use the exact role table below as the STARTING design palette. If contrast needs adjustments, change only the failing role and explain the difference. Body text >=4.5:1; meaningful UI elements >=3:1. Keep separate header/sidebar foreground tokens, especially Minecraft.
- UI palette MUST NOT be applied to renderer content (3D/Y-Layer scene, textures, block assets, Reality sky/ground, grid) or outside Project Screen/homepage.

## 23 semantic role tokens (proposed for Stitch; new design, NOT applied to code)

| Semantic role | Minecraft | Raccoon | Light | Dark |
|---|---|---|---|---|
| App Background | `#35372F` | `#181A1C` | `#F7F7F6` | `#08090C` |
| Header / Status bar | `#416F2C` | `#202326` | `#FFFFFF` | `#050608` |
| Sidebar | `#564330` | `#292D30` | `#F1F1F0` | `#0F1115` |
| Panel / Dialog | `#E4D9BE` | `#35393D` | `#FFFFFF` | `#13161B` |
| Input / Raised | `#F2E8D3` | `#42474C` | `#FAFAFA` | `#1A1D24` |
| Surface Muted | `#D2C1A3` | `#2C3034` | `#EEEEED` | `#0E1014` |
| Surface Hover | `#DAC8AC` | `#4D545A` | `#E8E8E7` | `#222630` |
| Selected Surface | `#B5CB98` | `#596068` | `#DEDEDD` | `#2C333D` |
| Border | `#887252` | `#687178` | `#CCCCCA` | `#343A45` |
| Primary Text | `#2A2117` | `#F5F4F1` | `#171717` | `#F2F3F5` |
| Secondary Text | `#5B4A35` | `#C5C9CD` | `#535353` | `#B7BEC9` |
| Header Text | `#F9F4E6` | `#F8F7F4` | `#171717` | `#F1F3F5` |
| Sidebar Text | `#FFF3DD` | `#EFEFED` | `#202020` | `#E6E9EF` |
| Disabled Text | `#776E61` | `#95999F` | `#848484` | `#858B96` |
| Primary / Accent | `#427A25` | `#D1D5D7` | `#252525` | `#A7B7CF` |
| Primary Hover | `#30631C` | `#ECEBE7` | `#111111` | `#C2D0E3` |
| Text on Primary | `#FFFFFF` | `#1B1D20` | `#FFFFFF` | `#0D121A` |
| Secondary Accent | `#C48845` | `#B7BEC2` | `#777777` | `#8D9AAF` |
| Focus / Outline | `#286B1C` | `#ECEBE7` | `#424242` | `#B1C3DE` |
| Success | `#246E3C` | `#8BD0A0` | `#237044` | `#80C89F` |
| Warning | `#835217` | `#E5B978` | `#8A5A1B` | `#E0B77C` |
| Danger / Error | `#AA3535` | `#F29BA2` | `#AB333C` | `#F08A98` |
| Info | `#315F83` | `#98BACB` | `#424242` | `#B2C4E0` |

## Component semantics

- App background: chrome behind work areas. Header and sidebar have independent colors; use their designated foreground colors.
- Panel / Dialog: long-readable content surface. Inputs raised above it. Muted/hover/selected surfaces are distinct. Borders should define regions but not create box-heavy noise.
- Primary / Accent: only the main action and the most important selected state. Primary Hover: interactive state. Text on Primary is specifically paired with both. Secondary Accent is decoration and DOES NOT automatically become a button surface or body text.
- Focus / Outline must be visible in keyboard navigation. Danger is for destructive actions; muted/disabled are never styled as active.
- Preserve original logo colors exactly, regardless of theme. Do not recolor the logo to match panels. Keep scaling proportionate, and keep transparent background.

## Settings navigation decision: Appearance contains two nested tabs

Keep FIVE top-level Settings sections: General / Appearance / Controls / Shortcuts / Accessibility. DO NOT create a sixth Environment section. Inside Appearance introduce TWO subtabs: **Interface** and **Workspace Background**.
- Interface: four application theme preview choices, font Comfortaa/Chakra Petch/Pangolin and font size. Theme selection and font selection remain independent.
- Workspace Background: Dark / Light / Reality independent of application UI theme. In Reality, show Ground choices Plains grass/Sand/Snow/Netherrack/Warped nylium/Crimson nylium/End stone and Sky choices Overworld day/Overworld night/Nether/The End, each with clear real previews, availability, selected states. Preserve any loading/unavailable states and keep the preview readable.
- Preserve Cancel, Apply, Save & Close, Reset defaults and correct independent draft state. Place header/footer stable, scroll CONTENT only. Never add toggles that change underlying behavior. Show theme cards visually without letting background choice replace UI theme.

## Required consistency across components

Workspace menu, toolbar, left block/decorations/groups pane, right inspector, JSON AI dialogs, Asset Manager, diagnostics, export flows, Settings and Help share the same component grammar, spacing, labels, action priority, footer patterns and dense-data readability. All 45 screenshots are ONE app with numerous states, not 45 unrelated pages. Use shared layout across four themes with distinctly styled decorations. Do not render the sample 3D structure as a flat UI background.


## Feature coverage
- Editor shell: brand logo, File/Edit/View/Tools/Settings/Help menus, Place/Select, 3D/Y-Layer, Undo/Redo, Camera, Fit, toolbars, sidebars, status. Actual 3D structure is functional content, not visual decoration.
- Left sidebar: Blocks, Decorations, variants, Painting gallery, Item Frames, Groups and destructive actions.
- Right sidebar: Selection, BlockState controls, Block Usage search/sort/metrics.
- Structure JSON import/export including validation, editor, save/download.
- External AI: Description, Available local content, Content limits, AI guidance, JSON example, prompt copying, independent state tabs.
- Minecraft export: Datapack ZIP / Structure NBT, namespace/path, compatibility, installation guide and copy actions.
- Asset Manager: Vanilla/Mods, cache, compatibility, import/preflight/progress/restore/activity.
- Project Diagnostics, Settings, Help, loading/disabled/warning/error, modal confirmations.

## Output sequence
Start with Workspace shell and shared component grammar, then Settings (including Appearance nested Interface / Workspace Background), then roll out the named feature groups/states. Produce Minecraft, Raccoon, Light and Dark versions with the **same functional layout/controls**. Label mockups `feature/state/theme`. Do not invent new features, erase controls, or produce implementation source code. All graphical mockups must use the exact supplied brand logo.
