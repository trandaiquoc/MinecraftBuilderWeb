# The Block Laundromat — Stitch workspace redesign pack (v3)

Contains 45 unchanged screenshots organized by feature/state; both EXACT ORIGINAL user-supplied logo files in SVG and transparent PNG; semantic palette V2; DESIGN.md; Stitch master prompt.

HOW TO USE STITCH:
1. Paste `DESIGN.md` into the "Paste existing DESIGN.md" area if available.
2. Upload the ORIGINAL `assets/the-block-laundromat-logo.svg` as the primary official logo. If SVG uploads are rejected, upload `assets/the-block-laundromat-logo.png` instead. Both are the original files from the user, not generated or reconstructed.
3. ZIP is a container for organization. If Stitch does not accept ZIP, extract and upload screenshots as PNG files in small feature-specific batches; start with `01-editor-overview.png`, `34-settings-appearance.png`, `35-settings-reality-presets.png` plus the original logo.
4. For the "Additional instructions" text area, copy `STITCH-MASTER-PROMPT.txt` or use it as the main instruction if DESIGN.md input does not work.
5. Design the INTERNAL Workspace only: four shared-layout themes Minecraft, Raccoon, Light, Dark; keep five Settings sections, with Appearance's two subtabs Interface / Workspace Background.
6. Preview designs only; no changes to product source code or user structure data are requested.

SOURCE FILES:
- `assets/the-block-laundromat-logo.svg` = exact user-supplied SVG.
- `assets/the-block-laundromat-logo.png` = exact user-supplied transparent PNG.
- `STITCH-WORKSPACE-PALETTE-V2.md` = proposed semantic palette for new design; original V1 is background reference only.
- `references/` = 45 screenshots.
